// Login And Logout:----------------------------------------------------------------   

 var userlogin = localStorage.getItem('nikeUser');
 //1. converts a JSON string into a JavaScript object.
 var userlogin1 = JSON.parse(userlogin);
 console.log(userlogin1);

 if (userlogin1) {
     document.getElementById("login").classList.add("d-none");
     document.getElementById("signup").classList.add("d-none");
     document.getElementById("logout").classList.add("d-block");
     document.getElementById("dropcart").classList.add("d-block");

     //1. Relod tay tyre Disply none class apvo and remove krvu Logout ne apvu:--     
     document.getElementById("logout").classList.remove("d-none");
     document.getElementById("dropcart").classList.remove("d-none");



 } else {
     document.getElementById("logout").classList.add("d-none");
     document.getElementById("dropcart").classList.add("d-none");
     document.getElementById("login").classList.add("d-block");
     document.getElementById("signup").classList.add("d-block");
 }

 document.getElementById("logout").addEventListener("click", function () {
     // 1. LocalStorage Clear:-
     localStorage.clear();
     // 2. LocalStorage Reload :-
     location.reload();
 });
