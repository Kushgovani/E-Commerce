// Register  :-----------------------------------------------------------------------------------

if (document.getElementsByClassName('form-signup').length) {
    document.querySelector('.form-signup').addEventListener('submit', e => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        var emailFormat = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

        if (username == '' || username.length <= 3) {
            toastr.error('Enter Username');
            return false;
        }

        if (email == '' || !email.match(emailFormat)) {
            toastr.error('Enter Valid Email');
            return false;
        }

        if (password == '' || password.length <= 5) {
            toastr.error('Enter Password');
            return false;
        }
        // IMP Poit :-------------------------------------------------------
        let formData = { username:username, email:email, password:password };
        register(formData);
    });
}

const register = async (formData) => {
    const res = await axios({
        method: 'post',
        url: '/signup',
        data: formData
    });
    if (res.data.status === 'success') {
        toastr.success(res.data.message, 'Success');
        //IMP  localStorage.setItem in js :--
        localStorage.setItem('nikeUser', JSON.stringify(res.data.userInfo));
        window.setTimeout(() => {
            location.assign('/nike');
        }, 1500);
    }
    if (res.data.status === 'fail') {
        toastr.error(res.data.message, 'Error');
    }
}  
// Register End

// Login :------------------------------------------------------------------------------------
if (document.getElementsByClassName("form-singin").length) {
    document.querySelector(".form-singin").addEventListener('submit', e => {
        e.preventDefault();
        const username = document.getElementById('username1').value;
        // console.log("username", username);
        const password = document.getElementById('password1').value;

        if (username == "") {
            toastr.error('Enter Your Username');
            return false;
        }
        if (password == "") {
            toastr.error('Enter Your Password');
            return false;
        }
        // IMP Poit :-------------------------------------------------------
        let formData = { username: username, password: password };
        login(formData);
    });
}

const login = async (formData) => {
    const res = await axios({
        method: 'post',
        url: '/singin',
        data: formData
    });
    if (res.data.status === 'success') {
        toastr.success(res.data.message, 'Success');
          //IMP  localStorage.setItem in js :--
        localStorage.setItem('nikeUser', JSON.stringify(res.data.userInfo));
        window.setTimeout(() => {
            location.assign('/nike');
        }, 1500);
    }
    if (res.data.status === 'fail') {
        toastr.error(res.data.message, 'Error');
    }
};
// Login End 
 
 
// Forgot Password  :-----------------------------------------------------------------------

if (document.getElementsByClassName("forgot-form").length) {
    document.querySelector(".forgot-form").addEventListener('submit', e => {
        e.preventDefault();
        const username = document.getElementById('forgotUser').value;
        // console.log("username", username);
        const password = document.getElementById('forgotPassword').value;

        if (username == "") {
            toastr.error('Enter Your Username');
            return false;
        }
        if (password == "") {
            toastr.error('Enter Your Password');
            return false;
        }
        // IMP Poit :-------------------------------------------------------
        let formData = { username: username, password: password };
        forgotpassword(formData);
    });
}

const forgotpassword = async (formData) => {
    const res = await axios({
        method: 'patch',
        url: '/forgotpassword',
        data: formData
    });
    if (res.data.status === 'success') {
        toastr.success(res.data.message, 'Success');
          //IMP  localStorage.setItem in js :--
        localStorage.setItem('nikeUser', JSON.stringify(res.data.userInfo));
        window.setTimeout(() => {
            location.assign('/nike');
        }, 1500);
    }
    if (res.data.status === 'fail') {
        toastr.error(res.data.message, 'Error');
    }
};




 