 
 function addcart(id) {

  let cart_id = id;

  let add_cart = { pro_id: cart_id };
  cart(add_cart);
}




const cart = async (cartdata) => {
  const res = await axios({
    method: 'post',
    url: '/cart',
    data: cartdata
  });
  console.log("cart", res);
};




// Remove Button Cart Remove Data:--------------------------
function deleteLSItem(id) {
  remove_cart(id);
}

const remove_cart = async (id) => {
  // console.log('id','/cart/'+ id);
  const removeData = await axios({
    method: 'delete',
    url: '/cart/' + id,
    data: id
  });
  // id="c-<%= cart._id%>"  **IMP** to Remove button click and Remove itam in Cart &  No Refers page :---
  document.getElementById('c-' + id).remove();
  console.log("remove Cart", removeData); 
};


 








