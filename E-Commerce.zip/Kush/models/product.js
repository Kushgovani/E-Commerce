const mongoose = require('mongoose');

const products = mongoose.Schema({

  pro_id: {
    type: String,
  },
  name: {
    type: String,
  },
  price: {
    type: String,
  },
  disc: {
    type: String,
  },
  image: {
    type: String,
  },

});



const product = mongoose.model('productbesses', products);
module.exports = product;