const mongoose = require('mongoose');

const maltipalproduct = mongoose.Schema({

  malpro_id: {
    type: String,
  },
  malname: {
    type: String,
  },
  malprice: {
    type: String,
  },
  maldisc: {
    type: String,
  },
  maltipalimg: {
    type: Array,
  }

});



const maltipalProduct = mongoose.model('maltipalProduct', maltipalproduct);
module.exports = maltipalProduct;