const mongoose = require('mongoose');

const add_cart = mongoose.Schema({
  user_id: {
    type: String,
  },
  pro_id: {
    type: String,
  },
});



const cart = mongoose.model('cart', add_cart);
module.exports = cart;