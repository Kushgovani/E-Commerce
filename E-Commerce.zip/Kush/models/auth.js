const mongoose = require('mongoose');
// const validator = require('validator');
const bcrypt = require('bcrypt');



const users = mongoose.Schema({

  username: {
    type: String,
    require: [true, 'Please Enter Your Username'],
    minlength: 3
  },
  email: {
    type: String,
    require: [true, 'Please Enter your email'],
    uniqued: true,
    lowercase: true,
  },
  password: {
    type: String,
    require: [true, 'Please Enter Your Password'],
    minlength: 6
    //select: false
  }

});

 
users.pre('save', async function (next) {
  if (!this.isModified('password')) return next;
  this.password = await bcrypt.hash(this.password, 10);
  next();
});


users.methods.correctPassword = async function (candidatePassword, userPassword) {
  return await bcrypt.compare(candidatePassword, userPassword);
};
  



const User = mongoose.model('user', users);
module.exports = User;