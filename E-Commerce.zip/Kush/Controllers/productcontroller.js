const Product = require('../models/product');

const maltipalProduct = require('../models/maltipalProduct');



exports.shoes = async (req, res) => {   
    var data = new Product();

    data.pro_id = req.body.pro_id;
    data.name = req.body.name;
    data.price = req.body.price;
    data.disc = req.body.disc;
    data.image = req.files.image.name;
    req.files.image.mv('./uploads/' + data.image);
    console.log("data", data);
    var save = data.save();
    if (save) {
        return res.send({
            message: 'Success',
            save: data
        });
    }
}


exports.maltipal = async (req, res) => {  
    var data = await new maltipalProduct();
    data.malpro_id = req.body.malpro_id;
    data.malname = req.body.malname;
    data.malprice = req.body.malprice;
    data.maldisc = req.body.maldisc;
   
    // IMP NOTE -------------------------------------------------------------------
    const dbData =  [];
    const kush = await req.files.maltipalimg;
    console.log("kush", kush);
    kush.forEach(file => {
        dbData.push(file.name);
        // New File ma Auto Save:--------
        const maltipal = file.mv('./maltipals/' + file.name);
    });
    data.maltipalimg = dbData;


    var save = data.save();
    if (save) {
        return res.send({
            message: 'Success',
            save: data
        });
    }
}





