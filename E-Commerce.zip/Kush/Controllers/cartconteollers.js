const cart = require('../models/cart');
 

exports.addcarts = async (req, res) => {
    var data = new cart();
    data.user_id = '638b0531b949976a3412ac39';
    data.pro_id = req.body.pro_id;
    const carts = await cart.create(data);
    if (carts) {
        return res.send({
            message: 'success',
            add_cart: carts
        })
    }
};


exports.deleteone = async (req, res, next) => {
    // console.log("kush",req.params.id);
    let doc = await cart.findByIdAndDelete(req.params.id);
    if (!doc) {
        return next(new Error('please provide valid record id'));
    }
    res.status(201).json({
        status: "success",
        message: "record deleted successfully",
        cart_Delete:doc
    });
};


exports.joinProduct = async (req, res) => {

    const docs = await cart.aggregate([
        {
            $lookup: {
                from: "productbesses",
                let: { productId: "$pro_id" },
                pipeline: [
                    {
                        $match: {
                            $expr: { $eq: ["$_id", { $toObjectId: "$$productId" }] },
                        },
                    },
                ],
                as: 'products'
            }
        },
        {
            $unwind: '$products'
        },

    ]);
    if (docs) {
        return res.send({
            message: 'Success',
            addProduct: docs
        });
    }
};

























































































































// Kartik bhai Exmapal:-----
    // const users = cart.aggregate([
    //     {
    //         $lookup: {
    //             from: "productbesses",
    //             localField: "product_id",
    //             let: { productId: "$proid" },
    //             pipeline: [
    //                 {
    //                     $match: {
    //                         $expr: { $eq: ["$_id", { $toObjectId: "$$productId" }] },
    //                     },
    //                 },
    //             ],
    //             as: "productbesses",
    //         },
    //     },
    //     {
    //         $project: {
    //             user_id: "$user_id",
    //             product: "$productbesses"
    //         },
    //     },
    // ]);

    // console.log("users", users);
    // return users;

// };

















// let doc = await cart.findById(req.params.id);
// if (!doc) {
//     return next(new Error('please provide valid record id'));
// }
// res.status(200).json({
//     status: "success",
//     getData: doc
// })

