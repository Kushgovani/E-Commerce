const User = require('../models/auth');
const Product = require('../models/product');
const bcrypt = require('bcrypt');
const maltipalProduct = require('../models/maltipalProduct');
const cart = require("../models/cart");
const jwt = require('jsonwebtoken');

generatetoken = id => jwt.sign({ id: id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXP });



// Main Page:--------------------------------------------------------------------------------------------------
exports.page = async (req, res) => {
   
   const productList = await Product.find();
   const maltipalProductbess = await maltipalProduct.find();
   // Cart **IMP**HTML ForEach :-Join Query:-Cart Conteoller.... 
   const docs = await cart.aggregate([
      {
         $lookup: {
            from: "productbesses",
            let: { productId: "$pro_id" },
            pipeline: [
               {
                  $match: {
                     $expr: { $eq: ["$_id", { $toObjectId: "$$productId" }] },
                  },
               },
            ],
            as: 'products'
         }
      },
      {
         $unwind: '$products'
      },

   ]);

   res.render('index', {
      productList: productList,
      maltipalProduct: maltipalProductbess,
      cartList: docs,
      cartLength: docs.length

   });
};





// singup :------------------------------------------------------------------------------------------------------- 
exports.signup = async (req, res) => {
   let userExist = await User.findOne({ username: req.body.username });
   let emailExist = await User.findOne({ email: req.body.email });
   if (userExist) {
      return res.status(200).json({
         status: 'fail',
         message: 'Username Already Exist.'
      });
   }

   if (emailExist) {
      return res.status(200).json({
         status: 'fail',
         message: 'Email Already Exist.'
      });
   }

   const user = new User({
      username: req.body.username,
      email: req.body.email,
      password: req.body.password,
   });

   user.save((err, user) => {
      if (err) {
         return res.status(200).json({
            status: 'fail',
            message: err.errors.username
         });
      }
      // Token :-------[]--------------------------->
      const token = generatetoken(user._id);
      return res.status(200).json({
         status: 'success',
         message: 'User Register Successfully.',
         token,
         userInfo: user
      });
   });
   console.log("user", user)

};



// singin :------------------------------------------------------------------------------------------------------- 
exports.signin = async (req, res) => {
   const user = await User.findOne({ username: req.body.username }).select('+password');
   if (user) {
      const password = await user.correctPassword(req.body.password, user.password);
      if (password) {
         // Token :-------[]-------------------------->
         const token = generatetoken(user._id);
         return res.status(200).json({
            status: 'success',
            token,
            message: 'Login Successfully.',
            userInfo: user
         });

      } else {
         return res.status(200).json({
            status: 'fail',
            message: 'Password Increct.'
         });
      }
   }

   else {
      return res.status(200).json({
         status: 'fail',
         message: ' Username Increct.'
      });
   }
};


// ----------- ForgotPassword :------------------------------------------------------------------------------------------------------------------
exports.forgotpassword = async (req, res) => {
   let username = await User.findOne({ username: req.body.username });
   if (!username) {
      res.status(201).json({
         status: 'fail',
         message: "Username ot found",
      });
      console.log('user not found :>> ');
   } else {
      // 1.Password Bcrypt in :--------------------
      var password1 = await bcrypt.hash(req.body.password, 10);
      //  const userPassword = await User.updateOne({username: req.body.username}, {$set :{password: password1}});
      const userPassword = await User.updateOne({ username: req.body.username }, { password: password1 });
      // Token :-------[]--------------------------->
      const token = generatetoken(username._id);
      res.status(201).json({
         status: 'success',
         token,
         message: "Password Change Success",
         Data: userPassword,
         userInfo: userPassword
      });
      console.log("usernew password", userPassword);
   }
}














