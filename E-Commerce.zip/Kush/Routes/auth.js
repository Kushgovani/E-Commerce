const route = require('express').Router();
const authcontroller = require('../Controllers/authcontroller');


route.get('/nike', authcontroller.page);
route.post('/signup', authcontroller.signup);
route.post('/singin', authcontroller.signin);
route.patch('/forgotpassword',authcontroller.forgotpassword)




module.exports = route;
