const productroutes = require('express').Router();
const productcontroller = require('../Controllers/productcontroller');


productroutes.post('/shoes',productcontroller.shoes);
 
productroutes.post('/maltipal',productcontroller.maltipal);



module.exports = productroutes;