const addtocart = require('express').Router();
const add_cart = require('../Controllers/cartconteollers');
 



addtocart.post('/',add_cart.addcarts);
 
addtocart.delete("/:id" ,add_cart.deleteone);

addtocart.get('/:id',add_cart.joinProduct);


 


module.exports = addtocart;