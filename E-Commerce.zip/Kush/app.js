
const mongoose= require('mongoose');

const app =require('./main');


const dotenv = require('dotenv');
dotenv.config({path:'./config.env'})



mongoose.connect(process.env.DATABASE,{
    useNewUrlParser:true,
}).then(()=>{
    console.log("DB Connection Done");
}).catch(()=>
{
    console.log("ERRRR");
})

var port = process.env.PORT || 8080 ;
app.listen(port,function(){
    console.log(`server Start ${port} `);
})


    