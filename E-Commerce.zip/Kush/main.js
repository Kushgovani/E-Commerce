const  express = require('express')
const app = express()
// Route middle:---
const authroute = require('./Routes/auth') 
const product = require('./Routes/product') 
const addtocart = require('./Routes/cart') 



const path = require('path');

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }))

const fileUpload = require('express-fileupload') 

app.use(fileUpload({
    useTempFiles : true,
    tempFileDir : '/tmp/'
}));
 
 

app.use(express.json());
 
app.use(bodyParser.json())
 

 


app.set('view engine','ejs');
app.set('views', path.join(__dirname,'view'));
app.use(express.static(path.join(__dirname +'/public')));
 



app.use('/', authroute)
app.use('/product',product)
app.use('/cart',addtocart)



module.exports=app;